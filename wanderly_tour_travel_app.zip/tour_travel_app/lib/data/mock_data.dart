import '../models/tour.dart';

class MockData {
  static const List<String> categories = [
    'All',
    'Beach',
    'Mountain',
    'Cultural',
    'Adventure',
    'City',
  ];

  static final List<Tour> tours = [
    Tour(
      id: 't1',
      title: 'Santorini Sunset Escape',
      location: 'Santorini, Greece',
      imageUrl: 'https://picsum.photos/seed/santorini/800/600',
      gallery: [
        'https://picsum.photos/seed/santorini1/800/600',
        'https://picsum.photos/seed/santorini2/800/600',
        'https://picsum.photos/seed/santorini3/800/600',
      ],
      price: 899,
      rating: 4.8,
      reviewCount: 342,
      durationDays: 5,
      category: 'Beach',
      description:
          'Wander whitewashed villages perched on volcanic cliffs, watch the world-famous Oia sunset, and relax on unique black-sand beaches on this unforgettable Aegean getaway.',
      itinerary: [
        'Day 1: Arrival & welcome dinner in Fira',
        'Day 2: Oia village walking tour & sunset viewing',
        'Day 3: Catamaran cruise to volcanic hot springs',
        'Day 4: Wine tasting at local vineyards',
        'Day 5: Free morning & departure',
      ],
      inclusions: [
        '4 nights hotel accommodation',
        'Daily breakfast',
        'Airport transfers',
        'Guided tours listed in itinerary',
      ],
    ),
    Tour(
      id: 't2',
      title: 'Swiss Alps Adventure',
      location: 'Interlaken, Switzerland',
      imageUrl: 'https://picsum.photos/seed/alps/800/600',
      gallery: [
        'https://picsum.photos/seed/alps1/800/600',
        'https://picsum.photos/seed/alps2/800/600',
      ],
      price: 1349,
      rating: 4.9,
      reviewCount: 218,
      durationDays: 7,
      category: 'Mountain',
      description:
          'Ride cable cars to snow-capped peaks, hike alpine trails, and take in panoramic views of the Eiger, Monch, and Jungfrau on this thrilling mountain adventure.',
      itinerary: [
        'Day 1: Arrival in Interlaken',
        'Day 2: Jungfraujoch "Top of Europe" excursion',
        'Day 3: Paragliding & hiking in Grindelwald',
        'Day 4: Lake Brienz boat cruise',
        'Day 5-6: Free days for optional adventure sports',
        'Day 7: Departure',
      ],
      inclusions: [
        '6 nights accommodation',
        'Daily breakfast & 3 dinners',
        'Rail pass for included excursions',
        'Professional mountain guide',
      ],
    ),
    Tour(
      id: 't3',
      title: 'Kyoto Cultural Journey',
      location: 'Kyoto, Japan',
      imageUrl: 'https://picsum.photos/seed/kyoto/800/600',
      gallery: [
        'https://picsum.photos/seed/kyoto1/800/600',
        'https://picsum.photos/seed/kyoto2/800/600',
      ],
      price: 1099,
      rating: 4.7,
      reviewCount: 401,
      durationDays: 6,
      category: 'Cultural',
      description:
          'Explore ancient temples, serene bamboo groves, and traditional tea houses while immersing yourself in the timeless culture of Japan\'s former imperial capital.',
      itinerary: [
        'Day 1: Arrival & Gion district evening walk',
        'Day 2: Fushimi Inari Shrine & Kiyomizu-dera Temple',
        'Day 3: Arashiyama bamboo grove & tea ceremony',
        'Day 4: Day trip to Nara deer park',
        'Day 5: Nishiki Market & cooking class',
        'Day 6: Departure',
      ],
      inclusions: [
        '5 nights traditional ryokan stay',
        'Daily breakfast',
        'Tea ceremony & cooking class',
        'Local English-speaking guide',
      ],
    ),
    Tour(
      id: 't4',
      title: 'Amazon Rainforest Expedition',
      location: 'Manaus, Brazil',
      imageUrl: 'https://picsum.photos/seed/amazon/800/600',
      gallery: [
        'https://picsum.photos/seed/amazon1/800/600',
        'https://picsum.photos/seed/amazon2/800/600',
      ],
      price: 1599,
      rating: 4.6,
      reviewCount: 128,
      durationDays: 8,
      category: 'Adventure',
      description:
          'Navigate winding rivers, spot exotic wildlife, and sleep in eco-lodges deep in the rainforest on an expedition built for true adventure seekers.',
      itinerary: [
        'Day 1: Arrival in Manaus',
        'Day 2-3: Riverboat journey & jungle lodge check-in',
        'Day 4: Night wildlife safari',
        'Day 5: Piranha fishing & indigenous village visit',
        'Day 6-7: Canopy walk & rainforest trekking',
        'Day 8: Departure',
      ],
      inclusions: [
        '7 nights eco-lodge accommodation',
        'All meals included',
        'Expert naturalist guide',
        'Boat & jungle excursions',
      ],
    ),
    Tour(
      id: 't5',
      title: 'New York City Highlights',
      location: 'New York, USA',
      imageUrl: 'https://picsum.photos/seed/nyc/800/600',
      gallery: [
        'https://picsum.photos/seed/nyc1/800/600',
        'https://picsum.photos/seed/nyc2/800/600',
      ],
      price: 749,
      rating: 4.5,
      reviewCount: 512,
      durationDays: 4,
      category: 'City',
      description:
          'Hit the iconic landmarks, catch a Broadway show, and taste your way through world-class neighborhoods on a fast-paced city break.',
      itinerary: [
        'Day 1: Arrival & Times Square evening tour',
        'Day 2: Statue of Liberty & 9/11 Memorial',
        'Day 3: Central Park, MoMA & Broadway show',
        'Day 4: Brooklyn walking tour & departure',
      ],
      inclusions: [
        '3 nights hotel accommodation',
        'Broadway show ticket',
        'City sightseeing pass',
        'Airport transfers',
      ],
    ),
    Tour(
      id: 't6',
      title: 'Bali Island Bliss',
      location: 'Bali, Indonesia',
      imageUrl: 'https://picsum.photos/seed/bali/800/600',
      gallery: [
        'https://picsum.photos/seed/bali1/800/600',
        'https://picsum.photos/seed/bali2/800/600',
      ],
      price: 799,
      rating: 4.7,
      reviewCount: 389,
      durationDays: 6,
      category: 'Beach',
      description:
          'Unwind with rice-terrace views, sacred temples, and pristine beaches on a rejuvenating escape to the Island of the Gods.',
      itinerary: [
        'Day 1: Arrival & welcome spa treatment',
        'Day 2: Ubud rice terraces & monkey forest',
        'Day 3: Temple hopping in Tanah Lot',
        'Day 4-5: Beach days in Seminyak',
        'Day 6: Departure',
      ],
      inclusions: [
        '5 nights villa accommodation',
        'Daily breakfast',
        'Spa treatment',
        'Private driver for excursions',
      ],
    ),
  ];
}
