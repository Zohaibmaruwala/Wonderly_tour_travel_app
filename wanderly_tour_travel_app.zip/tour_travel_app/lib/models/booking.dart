import 'tour.dart';

enum BookingStatus { confirmed, pending, cancelled }

class Booking {
  final String id;
  final Tour tour;
  final DateTime travelDate;
  final int travelers;
  final double totalPrice;
  final BookingStatus status;
  final DateTime bookedOn;

  const Booking({
    required this.id,
    required this.tour,
    required this.travelDate,
    required this.travelers,
    required this.totalPrice,
    required this.status,
    required this.bookedOn,
  });

  String get statusLabel {
    switch (status) {
      case BookingStatus.confirmed:
        return 'Confirmed';
      case BookingStatus.pending:
        return 'Pending';
      case BookingStatus.cancelled:
        return 'Cancelled';
    }
  }
}
