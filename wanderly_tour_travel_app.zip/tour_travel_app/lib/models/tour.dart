class Tour {
  final String id;
  final String title;
  final String location;
  final String imageUrl;
  final List<String> gallery;
  final double price;
  final double rating;
  final int reviewCount;
  final int durationDays;
  final String category;
  final String description;
  final List<String> itinerary;
  final List<String> inclusions;

  const Tour({
    required this.id,
    required this.title,
    required this.location,
    required this.imageUrl,
    required this.gallery,
    required this.price,
    required this.rating,
    required this.reviewCount,
    required this.durationDays,
    required this.category,
    required this.description,
    required this.itinerary,
    required this.inclusions,
  });
}
