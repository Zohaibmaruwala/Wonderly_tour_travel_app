import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/tour.dart';

class TourProvider extends ChangeNotifier {
  final List<Tour> _allTours = MockData.tours;
  String _selectedCategory = 'All';
  String _searchQuery = '';

  String get selectedCategory => _selectedCategory;
  String get searchQuery => _searchQuery;

  List<Tour> get tours {
    return _allTours.where((tour) {
      final matchesCategory =
          _selectedCategory == 'All' || tour.category == _selectedCategory;
      final matchesSearch = _searchQuery.isEmpty ||
          tour.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          tour.location.toLowerCase().contains(_searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    }).toList();
  }

  Tour tourById(String id) => _allTours.firstWhere((t) => t.id == id);

  void setCategory(String category) {
    _selectedCategory = category;
    notifyListeners();
  }

  void setSearchQuery(String query) {
    _searchQuery = query;
    notifyListeners();
  }
}
