import 'package:flutter/material.dart';
import '../models/booking.dart';
import '../models/tour.dart';

class BookingProvider extends ChangeNotifier {
  final List<Booking> _bookings = [];

  List<Booking> get bookings => List.unmodifiable(_bookings.reversed);

  Booking createBooking({
    required Tour tour,
    required DateTime travelDate,
    required int travelers,
  }) {
    final booking = Booking(
      id: 'BK${DateTime.now().millisecondsSinceEpoch}',
      tour: tour,
      travelDate: travelDate,
      travelers: travelers,
      totalPrice: tour.price * travelers,
      status: BookingStatus.confirmed,
      bookedOn: DateTime.now(),
    );
    _bookings.add(booking);
    notifyListeners();
    return booking;
  }

  void cancelBooking(String id) {
    final index = _bookings.indexWhere((b) => b.id == id);
    if (index != -1) {
      final old = _bookings[index];
      _bookings[index] = Booking(
        id: old.id,
        tour: old.tour,
        travelDate: old.travelDate,
        travelers: old.travelers,
        totalPrice: old.totalPrice,
        status: BookingStatus.cancelled,
        bookedOn: old.bookedOn,
      );
      notifyListeners();
    }
  }
}
