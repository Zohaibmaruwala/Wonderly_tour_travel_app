import 'package:flutter/material.dart';

class AuthProvider extends ChangeNotifier {
  bool _isLoggedIn = false;
  String _userName = '';
  String _userEmail = '';

  bool get isLoggedIn => _isLoggedIn;
  String get userName => _userName;
  String get userEmail => _userEmail;

  Future<void> login(String email, String password) async {
    // Simulated network delay. Replace with a real auth API call.
    await Future.delayed(const Duration(milliseconds: 800));
    _isLoggedIn = true;
    _userEmail = email;
    _userName = email.split('@').first;
    notifyListeners();
  }

  void continueAsGuest() {
    _isLoggedIn = true;
    _userName = 'Guest';
    _userEmail = '';
    notifyListeners();
  }

  void logout() {
    _isLoggedIn = false;
    _userName = '';
    _userEmail = '';
    notifyListeners();
  }
}
