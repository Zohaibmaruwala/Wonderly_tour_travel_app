import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/booking_provider.dart';
import '../providers/tour_provider.dart';
import '../theme/app_theme.dart';
import 'booking_confirmation_screen.dart';

class PaymentScreen extends StatefulWidget {
  final String tourId;
  final DateTime travelDate;
  final int travelers;

  const PaymentScreen({
    super.key,
    required this.tourId,
    required this.travelDate,
    required this.travelers,
  });

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  final _formKey = GlobalKey<FormState>();
  final _cardController = TextEditingController();
  final _nameController = TextEditingController();
  final _expiryController = TextEditingController();
  final _cvvController = TextEditingController();
  bool _isProcessing = false;

  @override
  void dispose() {
    _cardController.dispose();
    _nameController.dispose();
    _expiryController.dispose();
    _cvvController.dispose();
    super.dispose();
  }

  Future<void> _handlePayment() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isProcessing = true);

    // NOTE: This simulates a payment. Integrate a real payment provider
    // (e.g. Stripe) via its official Flutter SDK for production use.
    await Future.delayed(const Duration(seconds: 2));

    final tour = context.read<TourProvider>().tourById(widget.tourId);
    final booking = context.read<BookingProvider>().createBooking(
          tour: tour,
          travelDate: widget.travelDate,
          travelers: widget.travelers,
        );

    if (!mounted) return;
    setState(() => _isProcessing = false);

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => BookingConfirmationScreen(booking: booking),
      ),
      (route) => route.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) {
    final tour = context.read<TourProvider>().tourById(widget.tourId);
    final total = tour.price * widget.travelers;

    return Scaffold(
      appBar: AppBar(title: const Text('Payment')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Amount due',
                        style: TextStyle(color: AppColors.textLight)),
                    Text('\$${total.toStringAsFixed(0)}',
                        style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: AppColors.primary)),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              const Text('Card details',
                  style: TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'Cardholder name'),
                validator: (v) =>
                    (v == null || v.isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _cardController,
                keyboardType: TextInputType.number,
                maxLength: 16,
                decoration: const InputDecoration(
                    labelText: 'Card number', counterText: ''),
                validator: (v) =>
                    (v == null || v.length < 12) ? 'Enter a valid card number' : null,
              ),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _expiryController,
                      decoration: const InputDecoration(labelText: 'MM/YY'),
                      validator: (v) =>
                          (v == null || v.length < 4) ? 'Required' : null,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: TextFormField(
                      controller: _cvvController,
                      obscureText: true,
                      keyboardType: TextInputType.number,
                      maxLength: 3,
                      decoration: const InputDecoration(
                          labelText: 'CVV', counterText: ''),
                      validator: (v) =>
                          (v == null || v.length < 3) ? 'Required' : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _isProcessing ? null : _handlePayment,
                child: _isProcessing
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2),
                      )
                    : Text('Pay \$${total.toStringAsFixed(0)}'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
