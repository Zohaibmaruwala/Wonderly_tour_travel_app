# Wanderly — Tours & Travel Booking App

A Flutter app for browsing tour packages and booking trips, built to run on **both iOS and Android** from one codebase.

## What's included

- **Splash screen** with auto-routing based on login state
- **Login** with email/password (mocked) or "Continue as Guest"
- **Explore tab**: search + category filters + tour list
- **Tour details**: gallery image, description, itinerary, inclusions
- **Booking flow**: date picker, traveler count, live price summary
- **Mock payment screen**: card form → confirmation screen
- **My Trips tab**: booking history with status and cancel option
- **Profile tab**: user info + settings list + logout
- State management via `provider`; all data is in-memory mock data (`lib/data/mock_data.dart`) — swap in a real API later.

## Project structure

```
lib/
  main.dart                 # App entry point, providers, theme
  theme/app_theme.dart       # Colors, ThemeData
  models/                    # Tour, Booking
  data/mock_data.dart        # Sample tour catalogue
  providers/                 # Auth, Tour, Booking state (ChangeNotifier)
  screens/                   # One file per screen
  widgets/tour_card.dart     # Reusable tour list card
```

## Running it — this project has no `android/` or `ios/` folders yet

This sandbox doesn't have the Flutter SDK installed, so I wrote all the Dart source but couldn't run `flutter create` to generate the native `android/` and `ios/` platform folders (they're boilerplate, not something to hand-write). Here's how to get a runnable project on your machine, in ~2 minutes:

1. Install the [Flutter SDK](https://docs.flutter.dev/get-started/install) if you haven't already, and run `flutter doctor` to confirm setup.
2. Create a fresh scaffold project (this generates `android/`, `ios/`, and platform config):
   ```bash
   flutter create wanderly
   ```
3. Delete the generated `wanderly/lib` folder and `wanderly/pubspec.yaml`, then copy this project's `lib/` folder and `pubspec.yaml` into `wanderly/`.
4. Install dependencies:
   ```bash
   cd wanderly
   flutter pub get
   ```
5. Run on a simulator/emulator or physical device:
   ```bash
   flutter run
   ```
   - For iOS you'll need Xcode installed (macOS only) and a simulator or device.
   - For Android, an emulator via Android Studio or a physical device with USB debugging works.
6. To build release binaries:
   ```bash
   flutter build apk        # Android
   flutter build ios        # iOS (macOS + Xcode required)
   ```

## Next steps for a production app

- Replace mock data/auth/payment with real backend APIs (tours catalogue, user accounts, bookings database).
- Integrate a real payment SDK (e.g. Stripe's `flutter_stripe` package) instead of the mock card form.
- Add persistent storage (e.g. `shared_preferences` or a backend) so login and bookings survive app restarts.
- Add push notifications for booking reminders/updates.
- Add automated tests (`flutter_test`) for providers and widgets.
