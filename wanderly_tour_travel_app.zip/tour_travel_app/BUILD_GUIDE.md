# Building Installable Files for Wanderly

This guide covers two paths to get a real `.apk`/`.aab` (Android) and `.ipa` (iOS)
from this codebase: building locally, or building in the cloud with Codemagic
(useful if you don't own a Mac, which is otherwise required for iOS builds).

---

## Before either path: turn this into a runnable Flutter project

This zip contains the app's source (`lib/`, `pubspec.yaml`) but not the
native `android/`/`ios/` platform folders — those are boilerplate generated
by the Flutter CLI, not hand-written. Generate them once:

```bash
flutter create wanderly
# delete the placeholder lib/ and pubspec.yaml it creates
rm -rf wanderly/lib wanderly/pubspec.yaml
# copy this project's lib/ and pubspec.yaml into it
cp -r tour_travel_app/lib tour_travel_app/pubspec.yaml wanderly/
cd wanderly
flutter pub get
```

You now have a complete, runnable Flutter project.

---

## Path A: Build locally

### Android (works on Windows, macOS, or Linux)

1. Install the [Flutter SDK](https://docs.flutter.dev/get-started/install) and [Android Studio](https://developer.android.com/studio) (for the Android SDK + emulator).
2. Run `flutter doctor` and resolve anything it flags.
3. From the project root:
   ```bash
   # Installable file you can sideload onto any Android phone:
   flutter build apk --release
   # → build/app/outputs/flutter-apk/app-release.apk

   # File required for Play Store upload:
   flutter build appbundle --release
   # → build/app/outputs/bundle/release/app-release.aab
   ```
4. **To install the APK on a phone directly:** transfer `app-release.apk` to the phone (email, USB, cloud drive) and open it. The phone will prompt to enable "Install unknown apps" for that source — allow it, then install.
5. **To upload to Google Play:** create a account at [play.google.com/console](https://play.google.com/console) ($25 one-time fee), create an app listing, and upload the `.aab` file under Production (or Internal Testing first, which is recommended).
6. **Before your first real release**, replace the default debug signing with your own release keystore — see [Flutter's Android signing guide](https://docs.flutter.dev/deployment/android). Play Store submissions require this.

### iOS (macOS + Xcode required — no way around this, it's an Apple requirement)

1. You need: a Mac, [Xcode](https://apps.apple.com/us/app/xcode/id497799835) installed, and an active [Apple Developer Program](https://developer.apple.com/programs/) membership ($99/year).
2. Install Flutter SDK on the Mac, run `flutter doctor`.
3. Open `ios/Runner.xcworkspace` in Xcode (not `.xcodeproj`).
4. In Xcode: select the Runner target → Signing & Capabilities → choose your Apple Developer team → set a unique Bundle Identifier (e.g. `com.yourcompany.wanderly`).
5. From the project root:
   ```bash
   flutter build ipa --release
   # → build/ios/ipa/wanderly.ipa
   ```
6. **To install directly on your own device** for testing: connect the iPhone to the Mac and run `flutter run --release`, or use Xcode's "Devices and Simulators" window to install the built `.app`. Apple does not allow casually sideloading `.ipa` files onto other people's phones the way Android allows APKs — devices must be registered in your Developer account (for testing) or the app must go through the App Store / TestFlight.
7. **To upload to the App Store:** open the Xcode Organizer (Window > Organizer) after archiving, click "Distribute App" → "App Store Connect" → follow the prompts. Or use the Transporter app with the `.ipa`. You'll first need to create the app listing at [appstoreconnect.apple.com](https://appstoreconnect.apple.com).
8. **TestFlight** (Apple's beta testing platform) is the easiest way to get the `.ipa` onto testers' phones without a full App Store review — recommended before a public launch.

---

## Path B: Build in the cloud with Codemagic (no Mac needed, even for iOS)

This project includes a ready-to-use `codemagic.yaml` at its root.

1. Push the project (including `codemagic.yaml`) to a GitHub, GitLab, or Bitbucket repo.
2. Sign up free at [codemagic.io](https://codemagic.io) and connect that repo.
3. Codemagic auto-detects `codemagic.yaml` and shows two workflows: **Wanderly Android Build** and **Wanderly iOS Build**.
4. **Android workflow** — runs immediately, no extra setup. Produces a downloadable `.apk` and `.aab` as build artifacts.
5. **iOS workflow** — requires connecting your Apple Developer account once:
   - Go to Team settings → Integrations → App Store Connect.
   - Generate an API key at [appstoreconnect.apple.com](https://appstoreconnect.apple.com) (Users and Access → Keys) and add it in Codemagic.
   - Update `BUNDLE_ID` in `codemagic.yaml` to match an identifier registered in your Apple Developer account.
   - Codemagic then handles signing certificates and provisioning automatically on Apple's Mac-based cloud infrastructure — you never need to touch a Mac yourself.
6. Trigger a build. When it finishes, download the `.apk`/`.aab`/`.ipa` directly from the build's Artifacts tab, or let Codemagic auto-publish to Google Play / TestFlight (config placeholders are already in `codemagic.yaml`, commented with instructions).

---

## Quick reference: what each file is for

| File | Purpose |
|---|---|
| `app-release.apk` | Installable directly on any Android phone (sideload) |
| `app-release.aab` | Required format for Google Play Store submission |
| `.ipa` | Installable via TestFlight or App Store; direct sideloading is restricted by Apple to registered dev devices |
